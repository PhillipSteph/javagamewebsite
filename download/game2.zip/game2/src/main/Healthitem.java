package main;
public class Healthitem extends Item{
    int life;
    public Healthitem(int x, int y,int id, int life) {
        super(x, y, id);
        this.life = life;
    }
    @Override
    public void use(Player p) {
        p.life+=life;

    }
    public void move(int dx, int dy){
        this.x += dx;
        this.y += dy;
    }
}
