package main;

public class Playernode{
    int id,x,y;
    Playernode next;
    public Playernode(int id, int x, int y, Playernode next){
        this.id = id;
        this.x = x;
        this.y  = y;
        this.next = next;
    }
    public void move(int x, int y){
        this.x = x;
        this.y = y;
    }
}
