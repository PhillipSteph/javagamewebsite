package main;
public class Sizeitem extends Item{
    int size;
    public Sizeitem(int x, int y,int id, int size) {
        super(x, y, id);
        this.size = size;
    }
    @Override
    void use(Player p) {
        if(p.size<=240)
        p.size+= this.size;
    }
    public void move(int dx, int dy){
        this.x += dx;
        this.y += dy;
    }
}
