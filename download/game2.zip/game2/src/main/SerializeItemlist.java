package main;

import java.io.*;

public class SerializeItemlist {
    Itemlist list;
    public SerializeItemlist(Itemlist list){
        this.list = list;
    }
    public void serialize(String file){
        try {
            FileOutputStream fileOut = new FileOutputStream(file+".ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(this.list);
            out.close();
            fileOut.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }
    public Itemlist deserialize(String file){
        Itemlist list;
        try {
            FileInputStream fileIn = new FileInputStream(file+".ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            list = (Itemlist) in.readObject();
            in.close();
            fileIn.close();
            return list;
        } catch (IOException i) {
            i.printStackTrace();
            return null;
        } catch (ClassNotFoundException c) {
            System.out.println("File not found");
            c.printStackTrace();
            return null;
        }
    }
}