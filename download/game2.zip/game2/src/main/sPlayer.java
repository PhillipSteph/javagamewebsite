package main;

public class sPlayer{
    String name;
    int x;
    int y;
    Blockitem[][] blocklist;
    public sPlayer(String name, int x, int y, Blockitem[][] blocklist){
        this.name = name;
        this.x = x;
        this.y = y;
        this.blocklist = blocklist;
    }

}
