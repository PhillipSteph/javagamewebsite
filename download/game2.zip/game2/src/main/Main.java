
package main;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Main {
    public static GamePanel gamePanel = new GamePanel();
    public static void main(String[] args) throws IOException, FontFormatException, InterruptedException {

        final String[] ip = {"localhost"};
        final String[] username = {"user"};
        JFrame f=new JFrame("Game Launcher");
        Font font1 = new Font("SansSerif", Font.BOLD, 20);
        final JTextField tf=new JTextField();
        tf.setBounds(230,100, 300,100);
        tf.setFont(font1);
        tf.setText("enter Username");
        final JTextField tf2=new JTextField();
        tf2.setBounds(230,230, 300,100);
        tf2.setFont(font1);
        tf2.setText("enter Server ip");
        JButton button=new JButton("Start Game");
        button.setBounds(230,360,300,100);
        button.setFont(font1);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        f.add(button);f.add(tf);f.add(tf2);
        f.setSize(800,800);
        f.getContentPane().setBackground( Color.black );
        f.setLayout(null);
        f.setVisible(true);
        button.addActionListener(_ -> {
            username[0] = tf.getText();
            ip[0] = tf2.getText();
            if(username[0].equals("enter Username")){
                return;
            }
            if(ip[0].equals("enter Server ip")){
                return;
            }
            JFrame window = new JFrame();
            window.setUndecorated(true);
            window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            window.setResizable(false);
            window.setTitle("game2");
            window.add(gamePanel);
            window.pack();
            window.setLocationRelativeTo(null);
            window.setExtendedState(JFrame.MAXIMIZED_BOTH);
            window.setVisible(true);
            MyClient c = new MyClient();
            gamePanel.startGameThread(c);
            c.startClient(ip[0], username[0]);
        });


    }
}