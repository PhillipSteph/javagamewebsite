package main;
import java.io.Serializable;
public class Blockitem extends Item implements Serializable{
    int color;
    public Blockitem(int x, int y, int color, int id) {
        super(x, y, id);
        this.color = color;
    }
    @Override
    void use(Player p) {
        p.block[this.color]++;
    }
    public void move(int dx, int dy){
        this.x += dx;
        this.y += dy;
    }
}
