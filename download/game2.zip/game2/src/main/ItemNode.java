package main;

import java.io.*;

public class ItemNode implements Serializable {
    Item item;
    ItemNode next;
    public ItemNode(Item item, ItemNode next){
        this.item = item;
        this.next = next;
    }
}
