package main;

import java.io.Serializable;

public class Player implements Serializable {
int x,y,life,speed,size;
int block[];
int wx;
int wy;
    public Player(int x, int y, int life, int speed, int size, int block[]){
        this.x = x;
        this.y = y;
        this.life = life;
        this.speed = speed;
        this.size = size;
        wx = this.x;
        wy = this.y;
        this.block = block;
    }
    public void move(int dx, int dy){
        this.x += dx;
        this.y += dy;
        wx+=dx;
        wy+=dy;
    }
    public void setlocation(int x, int y){
        this.x = x;
        this.y = y;
    }
    public void setworldlocation(int x, int y){
        this.wx = x;
        this.wy = y;
    }
    public void addlife(int life){
        this.life += life;
    }
    public void removelife(int life){
        addlife(-life);
    }
    public void setspeed(int speed){
        this.speed = speed;
    }

}
