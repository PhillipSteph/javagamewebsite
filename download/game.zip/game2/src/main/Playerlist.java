package main;

public class Playerlist {
    static Playernode head;
    public Playerlist(){
        this.head = null;
    }
    public static void updatePlayer(int id, int x, int y){
        Playernode temp = head;
        while(temp!=null){
            if(temp.id==id){
                temp.move(x,y);
                return;
            }
            temp = temp.next;
        }
        addPlayer(id,x,y,null);
    }
    public static void addPlayer(int id, int x, int y, Itemlist blocklist){
        if(head == null){
            head = new Playernode(id,x,y,null);
        }else{
            Playernode temp = head;
            while(temp!=null){
                if(temp.next==null){
                    temp.next = new Playernode(id,x,y,null);
                    return;
                }
                temp = temp.next;
            }
        }
    }
    public static String printPlayer(){
        String s = "";
        Playernode temp = head;
        while(temp!=null){
            s+=temp.id+","+temp.x+","+temp.y+",";
            temp = temp.next;
        }
        return s;
    }

}
