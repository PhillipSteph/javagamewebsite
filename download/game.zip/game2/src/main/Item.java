package main;
import java.io.Serializable;
abstract public class Item implements Serializable{
    int x,y, id;
    public Item(int x, int y, int id){
        this.x = x;
        this.y = y;
        this.id = id;
    }
    abstract void move(int dx, int dy);
    abstract void use(Player p);
}
