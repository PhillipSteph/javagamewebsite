package main;

import java.io.*;
import java.net.Socket;

import static java.lang.System.nanoTime;

public class MyClient implements Runnable{
    Thread clientThread;
    public String ip;
    public String name;
    public sPlayer[] playerlist = {};
    public void startClient(String ip, String name){
        this.clientThread = new Thread(this);
        this.clientThread.start();
        this.ip = ip;
        this.name = name;
    }
    @Override
    public void run() {
        while(true){
            try {
                String str = "", str2 = "";
                str = GamePanel.player.wx + ":" + GamePanel.player.wy;
                Itemlist[] blocks = GamePanel.blocklist;
                int index=0;
                for(Itemlist currentblocklist : blocks ){
                    //rote, grüne, etc. listen
                    str+=":";
                    ItemNode temp = currentblocklist.head; // anfang der derzeitigen liste
                    if(currentblocklist.head ==null){
                        continue;
                    }
                    while(temp!=null){
                        str+=(temp.item.x-GamePanel.player.x)+","+(temp.item.y-GamePanel.player.y)+","+index+",";
                        temp = temp.next;
                    }
                    index++;
                }
                //str = x:y
                //+= dx-dy-dx-dy : dx-dy-dx-dy : dx-dy-dx-dy : dx-dy : dx-dy
                Socket s = new Socket(ip, 3333);//37.114.35.23
                DataInputStream din = new DataInputStream(s.getInputStream());
                DataOutputStream dout = new DataOutputStream(s.getOutputStream());
                dout.writeUTF(name + ":" + str);
                dout.flush();
                str2 = din.readUTF();
                dout.close();
                s.close();
                processdata(str2);
                Thread.sleep(100);
            }catch(Exception e){
                System.out.println(e);
                continue;
            }
        }
    }
    public void processdata(String s){
        String[] split = s.split("\n"); // trennt nach spielern
        int index = split.length;
        sPlayer newlist[] = new sPlayer[index-1];
        int i=0;
        for(String st : split){
            String player[] = st.split(":");
            String name = player[0];
            int x = Integer.parseInt(player[1]);
            int y = Integer.parseInt(player[2]);
            if(player.length>3) {
                String[] blockstringarray = player[3].split(",");
                int index2 = 0;
                Blockitem[] redblocks = new Blockitem[1000];
                Blockitem[] greenblocks = new Blockitem[1000];
                Blockitem[] blueblocks = new Blockitem[1000];
                Blockitem[] yellowblocks = new Blockitem[1000];
                Blockitem[] violetblocks = new Blockitem[1000];
                if (blockstringarray.length >= 1) {
                    for (int j = 0; j < blockstringarray.length; ) {
                        int bx = Integer.parseInt(blockstringarray[j++]);
                        int by = Integer.parseInt(blockstringarray[j++]);
                        int c = Integer.parseInt(blockstringarray[j++]);
                        redblocks[index2++] = new Blockitem(bx, by, c, 10000 + i);
                    }
                }
                Blockitem[][] blocks = {redblocks, greenblocks, blueblocks, yellowblocks, violetblocks};

                if (!this.name.equals(name)) {
                    newlist[i++] = new sPlayer(name, x, y, blocks);
                }
            }
        }
        this.playerlist = newlist;
    }
}

