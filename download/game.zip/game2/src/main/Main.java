
package main;
import javax.swing.JFrame;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static GamePanel gamePanel = new GamePanel();
    public static void main(String[] args) throws IOException, FontFormatException, InterruptedException {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("enter ip address to join server");
        String ip;
        try {
            ip = br.readLine();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Enter Username");
        String username;
        try {
            username = br.readLine();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        JFrame window = new JFrame();
        window.setUndecorated(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        window.setTitle("game2");
        window.add(gamePanel);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setExtendedState(JFrame.MAXIMIZED_BOTH);
        window.setVisible(true);
        MyClient c = new MyClient();
        gamePanel.startGameThread(c);
        c.startClient(ip,username);
    }
}