package main;
import javax.sound.sampled.*;
import java.io.*;

public class Music implements Runnable{
    Thread musicThread;

    public void startmusicThread(){
        musicThread = new Thread(this);
        musicThread.start();
    }
    File musicPath = new File("music.wav");
    public void run(){
            try {
                if(musicPath.exists()){
                    AudioInputStream audioInput = AudioSystem.getAudioInputStream(musicPath);
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioInput);
                    FloatControl gainControl =
                            (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(-10.0f);
                    clip.start();
                    clip.loop(1000);
                }
                else{
                    System.out.println("Couldn't find Music file");
                }
            }
            catch (Exception ex){
                ex.printStackTrace();
            }
    }
}
