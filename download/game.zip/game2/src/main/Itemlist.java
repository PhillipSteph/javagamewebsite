package main;

import java.io.*;

public class Itemlist implements Serializable{
    ItemNode head;
    ItemNode tail;
    int cnt;
    public Itemlist(){
        this.cnt = 0;
        this.head = null;
        this.tail = null;
    }
    public void addItem(Item it){
        cnt++;
        if(this.head == null){
            this.head = new ItemNode(it,tail);
        }else{
            if(tail==null){
                tail = new ItemNode(it,null);
                head.next = tail;
            }else{
                tail.next = new ItemNode(it,null);
                tail = tail.next;
            }
        }
    }
    public void moveall(int dx, int dy){
        ItemNode temp = this.head;
        while(temp!=null){
            temp.item.move(dx,dy);
            temp = temp.next;
        }
    }
    public void remove(int id){
        ItemNode temp = head;
        if(head.item.id == id){
            head = head.next;
            return;
        }
        while(temp!=null){
            if(temp.next.item.id == id){
                if(temp.next == tail){
                    tail = temp;
                }
                temp.next = temp.next.next;
                cnt--;
                return;
            }
            temp = temp.next;
        }
    }

}