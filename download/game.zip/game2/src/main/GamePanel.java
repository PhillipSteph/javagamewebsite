package main;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class GamePanel extends JPanel implements Runnable {
    KeyHandler keyH = new KeyHandler();
    MouseHandler MouseH = new MouseHandler();
    Thread gameThread;
    static GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
    static int screenWidth = gd.getDisplayMode().getWidth();
    static int screenHeight = gd.getDisplayMode().getHeight();
    MyClient client;
    int fps = 120;
    static int basespeed = 4;
    int itemsize = 48;
    static int[] hotbar = {0,0,0,0,0};//r,g,b,y,v
    int selectedslot = 0;
    public static Player player = new Player(screenWidth/2,screenHeight/2,100, basespeed,48, hotbar);
    public GamePanel(){
        this.addKeyListener(keyH);
        this.addMouseListener(MouseH);
        this.setFocusable(true);
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
    }
    public void startGameThread(MyClient c) {
        this.client = c;
        gameThread = new Thread(this);
        readlinesfromfile();
        readblocks(redblocklist,"redblocklist.txt",0);
        readblocks(greenblocklist,"greenblocklist.txt",1);
        readblocks(blueblocklist,"blueblocklist.txt",2);
        readblocks(yellowblocklist,"yellowblocklist.txt",3);
        readblocks(violetblocklist,"violetblocklist.txt",4);
        gameThread.start();
    }
    Itemlist healthlist = new Itemlist();
    Itemlist redlist = new Itemlist();
    Itemlist greenlist = new Itemlist();
    Itemlist yellowlist = new Itemlist();
    Itemlist violetlist = new Itemlist();
    Itemlist bluelist = new Itemlist();
    static Itemlist redblocklist = new Itemlist();
    static Itemlist greenblocklist = new Itemlist();
    static Itemlist blueblocklist = new Itemlist();
    static Itemlist yellowblocklist = new Itemlist();
    static Itemlist violetblocklist = new Itemlist();
    Itemlist[] itemlistlist = {healthlist, redlist, greenlist, bluelist, violetlist, yellowlist, redblocklist, greenblocklist, blueblocklist, yellowblocklist, violetblocklist};
    Itemlist[] collisionlist = {healthlist, redlist, greenlist, bluelist, yellowlist, violetlist};
    public static Itemlist[] blocklist = {redblocklist, greenblocklist, blueblocklist, yellowblocklist, violetblocklist};
    @Override
    public void run() {
        for(Itemlist i : blocklist){
            addblock(i,100000,100000,0);
        }
        while (gameThread != null) {
            update();
            repaint();
            try {
                Thread.sleep((long)1000/fps);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
       }
    }
        int dx = 0,dy = 0, cnt = 0, id = 0, changebuffer = 0;
    public void readlinesfromfile(){
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader("savedata/player.txt"));
            int x = Integer.parseInt(reader.readLine());
            int y = Integer.parseInt(reader.readLine());
            String line = reader.readLine();
            int i=0;
            while(line!=null){
                player.block[i++] = Integer.parseInt(line);
                line = reader.readLine();
            }
            reader.close();
            player.setworldlocation(x,y);
        } catch (IOException e) {
            player.setlocation(screenWidth/2,screenHeight/2);
            player.x = screenWidth/2;
            player.y = screenHeight/2;
           System.out.println("error with getting filedata");
        }
    }
    public void readblocks(Itemlist list, String file, int c){
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader("savedata/"+file));
            String line = reader.readLine();
            while(line!=null){
                String[] split = line.split(",");
                list.addItem(new Blockitem(player.x+Integer.parseInt(split[0]),player.y+Integer.parseInt(split[1]),c,id++));
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            player.setlocation(0,0);
            System.out.println("error with getting filedata");
        }
    }
    public void writetofile(){
        try {
            FileWriter myWriter = new FileWriter("savedata/player.txt");
            myWriter.write(player.wx+"\n"+player.wy+"\n"+player.block[0]+"\n"+player.block[1]+"\n"+player.block[2]+"\n"+player.block[3]+"\n"+player.block[4]);
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("error with writing filedata");
        }
    }
    public void saveblocks(Itemlist list,String file){
        try {
            FileWriter writer = new FileWriter("savedata/"+file);
            ItemNode temp = list.head;
            while(temp!=null){
                writer.write(temp.item.x-player.x+","+(temp.item.y-player.y)+"\n");
                temp = temp.next;
            }
            writer.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("error with writing filedata");
        }
    }
    public void update(){
        cnt++;changebuffer++;
        if(cnt == 1200) cnt = 0;
        if(cnt%24 == 0){
            addrandomitem(redlist, "red");
            addrandomitem(greenlist, "green");
            addrandomitem(bluelist, "blue");
            addrandomitem(yellowlist,"yellow");
            addrandomitem(violetlist,"violet");
        }
        if (keyH.escapePressed) {
            writetofile();
            saveblocks(redblocklist,"redblocklist.txt");
            saveblocks(greenblocklist,"greenblocklist.txt");
            saveblocks(blueblocklist,"blueblocklist.txt");
            saveblocks(yellowblocklist,"yellowblocklist.txt");
            saveblocks(violetblocklist,"violetblocklist.txt");
            gameThread = null;
            System.exit(0);
        }
        checkcollision(collisionlist);
        if(keyH.backspacePressed){
            removeblock(player.x-(player.wx%48),player.y-(player.wy%48));
        }
        if(keyH.enterPressed && player.block[selectedslot]>0 && blockfree(player.x-(player.wx%48),player.y-(player.wy%48))){
            addblock(blocklist[selectedslot],player.x-(player.wx%48),player.y-(player.wy%48),0);
            player.block[selectedslot]--;
        }
        if (keyH.upPressed) {
            dx = 0;
            dy = -player.speed;
        }
        if(keyH.downKeyPressed && changebuffer>=30){
            changebuffer = 0;
            if(selectedslot==4) selectedslot = 0;
            else selectedslot++;
        }
        if(keyH.upKeyPressed && changebuffer>=30){
            changebuffer = 0;
            if(selectedslot==0) selectedslot = 4;
            else selectedslot--;
        }
        if(keyH.LPressed && keyH.controlPressed){
            player.setlocation(screenWidth/2,screenHeight/2);
            writetofile();
            for(Itemlist itemlist : itemlistlist){
                itemlist.head = null;
            }
            saveblocks(redblocklist,"redblocklist.txt");
            saveblocks(redblocklist,"greenblocklist.txt");
            saveblocks(redblocklist,"blueblocklist.txt");
            saveblocks(redblocklist,"yellowblocklist.txt");
            saveblocks(redblocklist,"violetblocklist.txt");
            gameThread = null;
            System.exit(0);
        }
        if (keyH.downPressed) {
            dx = 0;
            dy = player.speed;
        }
        if (keyH.leftPressed) {
            dy = 0;
            dx = -player.speed;
        }
        if (keyH.rightPressed) {
            dy = 0;
            dx = player.speed;
        }
        if(player.x+dx<screenWidth/3 && keyH.leftPressed){
            movealllists(itemlistlist, player.speed,0);
        }else if(keyH.leftPressed){
            player.move(-player.speed,0);
        }
        if(player.y+dy<screenHeight/4 && keyH.upPressed){
            movealllists(itemlistlist, 0,player.speed);
        }else if(keyH.upPressed){
            player.move(0,-player.speed);
        }
        if(player.x+dx>(screenWidth-player.speed-screenWidth/3) && keyH.rightPressed){
            movealllists(itemlistlist, -player.speed,0);
        }else if(keyH.rightPressed){
            player.move(player.speed,0);
        }
        if(player.y+dy>(screenHeight-player.speed-screenHeight/4) && keyH.downPressed){
            movealllists(itemlistlist, 0,-player.speed);
        }else if(keyH.downPressed){
            player.move(0,player.speed);
        }
        if(keyH.shiftPressed){
            player.speed = basespeed*2;
        }else if(keyH.controlPressed){
            player.speed = basespeed/2;
        }else{
            player.speed = basespeed;
        }
    }
    public void movealllists(Itemlist[] array,int dx, int dy){
        for(Itemlist i : array){
            i.moveall(dx,dy);
        }
        player.wx -= dx;
        player.wy -= dy;
    }
    public boolean blockfree(int x, int y){
        for(Itemlist list : blocklist) {
            ItemNode temp = list.head;
            while (temp != null) {
                if (temp.item.x == x && temp.item.y == y) {
                    return false;
                }
                temp = temp.next;
            }
        }
        return true;
    }
    public void removeblock(int x, int y){
        for(Itemlist list : blocklist) {
            ItemNode temp = list.head;
            while (temp != null) {
                if (temp.item.x == x && temp.item.y == y) {
                    list.remove(temp.item.id);
                }
                temp = temp.next;
            }
        }
    }
    public void checkcollision(Itemlist[] li){
        for(Itemlist list : li) {
            ItemNode temp = list.head;
            while (temp != null) {
                if ((player.x + player.size >= temp.item.x && temp.item.x + itemsize >= player.x) && (player.y + player.size >= temp.item.y && temp.item.y + itemsize >= player.y)) {
                    temp.item.use(player);
                    list.remove(temp.item.id);
                    return;
                }
                temp = temp.next;
            }
        }
    }
    public void addrandomitem(Itemlist list, String type){
        Random r = new Random();
        int res = r.nextInt(screenWidth*3)-screenWidth;
        int res1 = r.nextInt(screenHeight*3)-screenHeight;
        if(type.equals("health")) list.addItem(new Healthitem(res,res1,id++,3));
        if(type.equals("size")) list.addItem(new Sizeitem(res,res1,id++,2));
        if((type.equals("red")|| type.equals("yellow") || type.equals("blue") || type.equals("green") || type.equals("violet")) && list.cnt<=100){
            int c = 0;
            switch(type){
                case "green": c=1;break;
                case "blue": c=2;break;
                case "yellow": c=3;break;
                case "violet": c=4;break;
                default: break;
            }
            list.addItem(new Blockitem(res,res1,c,id++));
        }
    }
    public void addblock(Itemlist list, int x, int y, int c){
        list.addItem(new Blockitem(x,y,c,id++));
    }
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g.setColor(Color.black);
        g.fillRect(0, 0, screenWidth, screenHeight);
        g.setColor(Color.white);
        drawItems(g, healthlist, Color.orange);
        drawItems(g, redlist,Color.red);
        drawItems(g, greenlist,Color.green);
        drawItems(g, bluelist,Color.blue);
        drawItems(g, yellowlist, Color.yellow);
        drawItems(g, violetlist, Color.pink);
        drawBlocks(g,redblocklist,Color.red);
        drawBlocks(g,yellowblocklist,Color.yellow);
        drawBlocks(g,violetblocklist,Color.pink);
        drawBlocks(g,blueblocklist,Color.blue);
        drawBlocks(g,greenblocklist,Color.green);
        if(keyH.tabPressed) drawTabbar(g);
        drawsPlayer(g);
        drawhotbar(g);
        //player.x-(player.wx%48),player.y-(player.wy%48)
        drawblockpreview(g);
        drawPlayer(g,player,Color.white);
        g.drawString("Player: posX: "+player.wx+"  posY: "+player.wy,100,100);
        g2.dispose();
    }
    public void drawItems(Graphics g, Itemlist list, Color c){
        ItemNode temp = list.head;
        g.setColor(c);
        while(temp!=null){
            g.drawRect(temp.item.x,temp.item.y,itemsize,itemsize);
            temp = temp.next;
        }
    }
    //player.x-(player.wx%48),player.y-(player.wy%48)
    public void drawblockpreview(Graphics g){
        g.setColor(Color.gray);
        g.drawRect(player.x-(player.wx%48),player.y-(player.wy%48),48,48);
    }
    public void drawTabbar(Graphics g){
        try{
            g.setFont(new Font("arial", Font.BOLD,20));
            int i = 0;
            for(sPlayer pl : client.playerlist){
                g.drawString(pl.name+":\tX: "+pl.x+"\tY:"+pl.y,screenWidth-300,80+i*40);
                i++;
            }
                g.drawRect(screenWidth-305,45,290,i*45);
        }catch(Exception e){
            g.drawString("error with getting playerdata",screenWidth-300,50);
        }
    }
    Color[] colorarr = {Color.red,Color.green,Color.blue,Color.yellow,Color.pink};
    public void drawhotbar(Graphics g){
        int i=0;
        int buffer = screenWidth/2-250;
        for( int slot : hotbar){
            Font f = new Font("arial", Font.BOLD,20);
            g.setFont(f);
            g.setColor(colorarr[i]);
            g.drawRect(buffer+i*100,screenHeight-80,70,70);
            if( i == selectedslot){
                if(slot!=0) g.setColor(colorarr[i]);
                else g.setColor(Color.gray);
                g.fillRect(buffer+i*100,screenHeight-80,70,70);
                g.setColor(Color.white);
            }
            g.drawString(slot+"",buffer+4+i*100,screenHeight-16);
            i++;
        }
    }
    public void drawBlocks(Graphics g, Itemlist list, Color c){
        ItemNode temp = list.head;
        g.setColor(c);
        while(temp!=null){
            g.fillRect(temp.item.x,temp.item.y,itemsize,itemsize);
            temp = temp.next;
        }
    }
    public void drawPlayer(Graphics g, Player p, Color c){
        g.setColor(c);
        g.fillRect(p.x,p.y,p.size,p.size);
    }
    public void drawsPlayer(Graphics g){
        try{

        for(sPlayer pl : client.playerlist){
            int distx = player.x-(player.wx-pl.x);
            int disty = player.y-(player.wy-pl.y);
                g.drawString(pl.name,distx,disty-20);
                for(Blockitem[] blocklist : pl.blocklist){
                    for(Blockitem block : blocklist){
                        if(block!=null){
                            g.setColor(colorarr[block.color]);
                            g.fillRect(distx+block.x,disty+block.y,48,48);
                            g.setColor(Color.white);
                            g.drawRect(distx+block.x,disty+block.y,48,48);
                        }
                    }
                }
            g.setColor(Color.gray);
            g.fillRect(distx,disty,48,48);
        }
        }catch(Exception e){
            g.drawString("error with getting playerdata",screenWidth-300,50);
        }
    }
}
